#!/bin/bash
# T.A.C.O. Twosday: Python Edition - Debian / Ubuntu Launcher
# Creates a virtual environment, installs dependencies, and runs from source.

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"
VENV_DIR="$SCRIPT_DIR/.venv"

# ── Check system dependencies ─────────────────────────────────────────
MISSING_PKGS=""
dpkg -s python3 &>/dev/null 2>&1 || MISSING_PKGS="$MISSING_PKGS python3"
dpkg -s python3-venv &>/dev/null 2>&1 || MISSING_PKGS="$MISSING_PKGS python3-venv"
dpkg -s python3-pip &>/dev/null 2>&1 || MISSING_PKGS="$MISSING_PKGS python3-pip"
dpkg -s libegl1 &>/dev/null 2>&1 || MISSING_PKGS="$MISSING_PKGS libegl1"
dpkg -s libgl1 &>/dev/null 2>&1 || {
    dpkg -s libgl1-mesa-glx &>/dev/null 2>&1 || MISSING_PKGS="$MISSING_PKGS libgl1"
}

if [ -n "$MISSING_PKGS" ]; then
    echo "Missing system packages:$MISSING_PKGS"
    echo ""
    echo "Install them with:"
    echo "  sudo apt install$MISSING_PKGS"
    echo ""
    echo "For full multimedia support you may also want:"
    echo "  sudo apt install libxcb-cursor0 libxcb-icccm4 libxcb-keysyms1 libxcb-shape0 libpulse0"
    exit 1
fi

PY=python3
PY_VER=$($PY -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
echo "T.A.C.O. Twosday - Using Python $PY_VER"

# ── Create / activate virtual environment ──────────────────────────────
if [ ! -d "$VENV_DIR" ]; then
    echo "Creating virtual environment (first run)..."
    $PY -m venv "$VENV_DIR"
fi

source "$VENV_DIR/bin/activate"

# ── Install / update dependencies ──────────────────────────────────────
MARKER="$VENV_DIR/.taco_deps_installed"
REQS="$SCRIPT_DIR/taco/requirements.txt"

if [ ! -f "$MARKER" ] || [ "$REQS" -nt "$MARKER" ]; then
    echo "Installing dependencies..."
    pip install --upgrade pip 2>/dev/null
    pip install -r "$REQS"
    touch "$MARKER"
    echo "Dependencies installed."
fi

# ── Launch ─────────────────────────────────────────────────────────────
echo "Starting T.A.C.O. Twosday..."
exec python taco/main.py "$@"
