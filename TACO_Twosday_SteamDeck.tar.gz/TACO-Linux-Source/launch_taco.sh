#!/bin/bash
# T.A.C.O. Twosday: Python Edition - Linux / Steam Deck Launcher
# Creates a virtual environment, installs dependencies, and runs from source.

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"
VENV_DIR="$SCRIPT_DIR/.venv"

# ── Find Python 3 ─────────────────────────────────────────────────────
if command -v python3 &>/dev/null; then
    PY=python3
elif command -v python &>/dev/null; then
    PY=python
else
    echo "ERROR: Python 3 is not installed."
    echo "  Steam Deck:     sudo pacman -S python python-pip"
    echo "  Ubuntu/Debian:  sudo apt install python3 python3-venv python3-pip"
    exit 1
fi

PY_VER=$($PY -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
echo "T.A.C.O. Twosday - Using Python $PY_VER"

# ── Create / activate virtual environment ──────────────────────────────
if [ ! -d "$VENV_DIR" ]; then
    echo "Creating virtual environment (first run)..."
    $PY -m venv "$VENV_DIR" || {
        echo "ERROR: Failed to create venv. Install the venv module:"
        echo "  Steam Deck:     sudo pacman -S python"
        echo "  Ubuntu/Debian:  sudo apt install python3-venv"
        exit 1
    }
fi

# Activate venv
source "$VENV_DIR/bin/activate"

# ── Install / update dependencies ──────────────────────────────────────
MARKER="$VENV_DIR/.taco_deps_installed"
REQS="$SCRIPT_DIR/taco/requirements.txt"

# Reinstall if marker missing or requirements.txt is newer
if [ ! -f "$MARKER" ] || [ "$REQS" -nt "$MARKER" ]; then
    echo "Installing dependencies..."
    pip install --upgrade pip 2>/dev/null
    pip install -r "$REQS"
    touch "$MARKER"
    echo "Dependencies installed."
fi

# ── Set environment for Steam Deck / Linux GL ─────────────────────────
# Use EGL instead of GLX — more reliable under Gamescope / Xwayland
export QT_XCB_GL_INTEGRATION=xcb_egl

# Tell PyOpenGL to use EGL so it can find the EGL-created context
export PYOPENGL_PLATFORM=egl

# Disable Qt session management (avoids warnings on some desktops)
export QT_NO_SESSIONMANAGER=1

# ── Launch ─────────────────────────────────────────────────────────────
echo "Starting T.A.C.O. Twosday..."
exec python taco/main.py "$@"
